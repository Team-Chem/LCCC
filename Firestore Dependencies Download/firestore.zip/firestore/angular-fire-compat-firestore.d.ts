/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@angular/fire/compat/firestore" />
export * from './public_api';
